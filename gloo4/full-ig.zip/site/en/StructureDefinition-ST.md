# ST - gloo4 v0.1.0

## Logical Model: ST 

 
Textsträng 

**Usages:**

* Use this Logical Model: [Analysgrupp](StructureDefinition-Analysgrupp.md), [Analysutrustning : Resurs](StructureDefinition-Analysutrustning-Resurs.md), [Hälso- och sjukvårdspersonal : Hälso- och sjukvårdspersonal](StructureDefinition-Halso--och-sjukvardspersonal-Halso--och-sjukvardsperson.md), [Kontaktinformation](StructureDefinition-Kontaktinformation.md)... Show 8 more, [Laboratorieanalys : Aktivitet](StructureDefinition-Laboratorieanalys-Aktivitet.md), [Laboratorieanalysresultat : Observation](StructureDefinition-Laboratorieanalysresultat-Observation.md), [Laboratoriesvar : Dokument](StructureDefinition-Laboratoriesvar-Dokument.md), [Organisatorisk enhet : Organisatorisk enhet](StructureDefinition-Organisatorisk-enhet-Organisatorisk-enhet.md), [Person : Person](StructureDefinition-Person-Person.md), [Prov : Resurs](StructureDefinition-Prov-Resurs.md), [Referens](StructureDefinition-Referens.md) and [Remiss : Dokument](StructureDefinition-Remiss-Dokument.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/gloo4|current/StructureDefinition/StructureDefinition-ST.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-ST.csv), [Excel](../StructureDefinition-ST.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ST",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "http://example.org/fhir/gloo4/StructureDefinition/ST",
  "version" : "0.1.0",
  "name" : "ST",
  "title" : "ST",
  "status" : "draft",
  "date" : "2026-09-18T11:14:11+00:00",
  "publisher" : "xmi-to-fsh",
  "contact" : [{
    "name" : "xmi-to-fsh",
    "telecom" : [{
      "system" : "url",
      "value" : "https://github.com/oskthu2/xmi-to-fsh"
    }]
  }],
  "description" : "Textsträng",
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "http://example.org/fhir/gloo4/StructureDefinition/ST",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "ST",
      "path" : "ST",
      "short" : "ST",
      "definition" : "Textsträng"
    }]
  }
}

```
