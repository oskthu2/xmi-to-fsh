# Referensintervall - gloo4 v0.1.0

## Example Binary: Referensintervall

This content is an example of the [Referens](StructureDefinition-Referens.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://example.org/fhir/gloo4/StructureDefinition/Referens",
  "intervall": "34-45 g/L"
}

```



## Resource Binary Content

application/fhir+json:

```
{snip}
```
